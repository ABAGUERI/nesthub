import React, { useEffect, useState } from 'react';
import { useAuth } from '@/shared/hooks/useAuth';
import { getCurrentRotation, generateNextWeekRotation } from '../services/rotation.service';
import { RotationWeek } from '@/shared/types/kitchen.types';

// Catégories simplifiées pour la roue indicative
const CATEGORIES = [
  { id: 'cuisine', name: 'Cuisine', icon: '👨‍🍳', color: 'cuisine-icon' },
  { id: 'salle-bain', name: 'Salle de Bain', icon: '🚿', color: 'salle-bain-icon' },
  { id: 'animaux', name: 'Animaux', icon: '🐾', color: 'animaux-icon' }
];

export const RotationPanel: React.FC = () => {
  const { user } = useAuth();
  const [rotation, setRotation] = useState<RotationWeek | null>(null);
  const [loading, setLoading] = useState(true);
  const [rotating, setRotating] = useState(false);
  const [generating, setGenerating] = useState(false);

  useEffect(() => {
    loadRotation();
  }, [user]);

  const loadRotation = async () => {
    if (!user) {
      setLoading(false);
      return;
    }

    setLoading(true);
    try {
      const data = await getCurrentRotation(user.id);
      setRotation(data);
    } catch (err) {
      console.error('Rotation load error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleRotate = async () => {
    if (!user || rotating) return;
    
    setRotating(true);
    
    // Animation visuelle
    await new Promise(resolve => setTimeout(resolve, 800));
    
    try {
      setGenerating(true);
      await generateNextWeekRotation(user.id);
      await loadRotation();
    } catch (err) {
      console.error('Rotation failed:', err);
    } finally {
      setRotating(false);
      setGenerating(false);
    }
  };

  const formatWeek = (isoDate: string): string => {
    const date = new Date(isoDate);
    return `${date.getDate()}/${date.getMonth() + 1}`;
  };

  return (
    <div className="kitchen-card-enhanced">
      <div className="card-header">
        <div>
          <h2 className="card-title">Rotation des tâches</h2>
          <p className="card-subtitle">
            {rotation ? `Semaine du ${formatWeek(rotation.weekStart)}` : 'Chargement...'}
          </p>
        </div>
        <button 
          className="ghost-btn" 
          onClick={loadRotation} 
          disabled={loading}
          type="button"
        >
          {loading ? '⏳' : '🔄'}
        </button>
      </div>

      {/* Roue indicative simplifiée */}
      <div className="rotation-wheel-simple">
        <div className="wheel-categories">
          {CATEGORIES.map((category) => (
            <div key={category.id} className="wheel-category">
              <div className={`category-icon ${category.color}`}>
                {category.icon}
              </div>
              <span className="category-name">{category.name}</span>
            </div>
          ))}
        </div>

        <div className="rotation-controls">
          <div className="rotation-status">
            <strong>Rotation indicative</strong> — Cliquez pour générer les tâches officielles
          </div>
          
          <button 
            className="rotate-button"
            onClick={handleRotate}
            disabled={rotating || !user}
            type="button"
          >
            {rotating ? (
              <>
                <span style={{ animation: 'spin 1s linear infinite' }}>⟳</span>
                Rotation en cours...
              </>
            ) : generating ? (
              'Génération des tâches...'
            ) : (
              '⟳ Générer nouvelle rotation'
            )}
          </button>
        </div>
      </div>

      {/* Tâches officielles générées */}
      <div className="rotation-tasks-official">
        {loading ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', padding: '20px 0' }}>
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="skeleton-line" style={{ height: '52px', borderRadius: '12px' }}></div>
            ))}
          </div>
        ) : rotation?.assignments && rotation.assignments.length > 0 ? (
          <>
            <div style={{ 
              fontSize: '13px', 
              color: '#94a3b8', 
              fontWeight: '700', 
              marginBottom: '12px',
              padding: '0 4px'
            }}>
              Tâches officielles ({rotation.assignments.length})
            </div>
            
            {rotation.assignments.map((assignment, index) => (
              <div key={index} className="rotation-task-item">
                <div className="task-name">
                  {assignment.role.length > 20 ? `${assignment.role.substring(0, 18)}...` : assignment.role}
                </div>
                <div className="task-assignee">
                  {assignment.assigneeAvatarUrl ? (
                    <img 
                      src={assignment.assigneeAvatarUrl} 
                      alt={assignment.assigneeName}
                      className="assignee-avatar"
                    />
                  ) : null}
                  <span className="assignee-name">
                    {assignment.assigneeName.length > 8 ? `${assignment.assigneeName.substring(0, 6)}...` : assignment.assigneeName}
                  </span>
                </div>
              </div>
            ))}
          </>
        ) : (
          <div style={{ 
            display: 'flex', 
            flexDirection: 'column', 
            alignItems: 'center', 
            justifyContent: 'center',
            flex: 1,
            color: '#94a3b8',
            textAlign: 'center',
            padding: '40px 20px'
          }}>
            <div style={{ fontSize: '48px', marginBottom: '16px', opacity: 0.5 }}>📋</div>
            <div style={{ fontSize: '14px', fontWeight: '700', marginBottom: '8px' }}>
              Aucune rotation configurée
            </div>
            <div style={{ fontSize: '12px' }}>
              Utilisez le bouton ci-dessus pour générer une rotation
            </div>
          </div>
        )}
      </div>
    </div>
  );
};