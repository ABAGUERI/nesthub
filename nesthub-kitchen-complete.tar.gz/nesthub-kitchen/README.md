# 🍽️ Hub Familial 2.0 - Écran Cuisine (Code Complet)

## 📋 Vue d'ensemble

Code production-ready pour l'écran Cuisine et la configuration associée dans Paramètres.

**Fonctionnalités complètes :**
- ✅ Menu hebdomadaire persisté dans Supabase
- ✅ Liste d'épicerie via Google Tasks (source unique)
- ✅ Rotation de tâches hebdomadaires configurables
- ✅ Gestion famille unifiée (enfants + adultes)
- ✅ UI optimisée tactile Nest Hub
- ✅ Architecture additive sans casse

---

## 🗂️ Structure du code

```
nesthub-kitchen/
├── migrations/
│   └── 20251229_weekly_menu_storage.sql    # Migration Supabase
│
├── src/
│   ├── shared/types/
│   │   └── kitchen.types.ts                # Types TypeScript
│   │
│   ├── features/
│   │   ├── kitchen/
│   │   │   ├── components/
│   │   │   │   ├── MenuPanel.tsx           # Composant Menu
│   │   │   │   ├── GroceryPanel.tsx        # Composant Épicerie
│   │   │   │   └── RotationPanel.tsx       # Composant Rotation
│   │   │   ├── services/
│   │   │   │   ├── menu.service.ts         # Service Menu Supabase
│   │   │   │   └── rotation.service.ts     # Service Rotation Supabase
│   │   │   ├── KitchenPage.tsx             # Page principale
│   │   │   └── KitchenPage.css             # Styles complets
│   │   │
│   │   └── config/
│   │       └── components/tabs/
│   │           ├── FamilyTab.tsx           # Onglet Famille + Rotation
│   │           └── FamilyTab.css           # Styles FamilyTab
│
└── README.md                                # Ce fichier
```

---

## 🚀 Installation

### 1. Migration Supabase

Exécute la migration pour créer la table `weekly_menu` :

```bash
# Via Supabase CLI
supabase migration new weekly_menu_storage
# Copie le contenu de migrations/20251229_weekly_menu_storage.sql
supabase db push

# Ou via Dashboard Supabase
# SQL Editor → Colle le contenu du fichier SQL → Run
```

### 2. Copier les fichiers

Copie les fichiers dans ton projet en respectant la structure :

```bash
# Types
cp src/shared/types/kitchen.types.ts <ton-projet>/src/shared/types/

# Kitchen
cp -r src/features/kitchen/* <ton-projet>/src/features/kitchen/

# Config
cp src/features/config/components/tabs/FamilyTab.tsx <ton-projet>/src/features/config/components/tabs/
cp src/features/config/components/tabs/FamilyTab.css <ton-projet>/src/features/config/components/tabs/
```

### 3. Mettre à jour les imports

Dans `ConfigPage.tsx`, remplace l'import de `ChildrenTab` :

```typescript
// AVANT
import { ChildrenTab } from './components/tabs/ChildrenTab';

// APRÈS
import { FamilyTab } from './components/tabs/FamilyTab';
import './components/tabs/FamilyTab.css';

// Dans le render
<FamilyTab />  // Au lieu de <ChildrenTab />
```

Dans `App.tsx`, vérifie que la route `/kitchen` existe :

```typescript
import { KitchenPage } from '@/features/kitchen/KitchenPage';

// Dans les routes
<Route
  path="/kitchen"
  element={
    <ProtectedRoute>
      <KitchenPage />
    </ProtectedRoute>
  }
/>
```

### 4. Vérifier les dépendances

Assure-toi que ces dépendances sont installées :

```json
{
  "dependencies": {
    "@supabase/supabase-js": "^2.39.0",
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.21.0"
  }
}
```

---

## 🎯 Utilisation

### Flux utilisateur

**1. Configuration initiale (Paramètres → Famille)**

1. Ajouter les membres de la famille (enfants + adultes)
2. Choisir icônes (abeille, coccinelle, papillon, chenille)
3. Configurer les rôles de rotation (Cuisine, Vaisselle, etc.)
4. Assigner les membres aux rôles
5. Sauvegarder la rotation

**2. Écran Cuisine (Dashboard → Cuisine)**

- **Menu** : Cliquer sur un jour → Ajouter/modifier repas → Enregistrer
- **Épicerie** : Ajouter items → Cocher/décocher → Sync Google Tasks auto
- **Rotation** : Consulter les assignations de la semaine

### Navigation

```
Dashboard → Cuisine
         ↓
   ┌─────────────┐
   │   CUISINE   │
   ├─────────────┤
   │   Menu      │  ← Scroll interne
   │   Épicerie  │  ← Scroll interne
   │   Rotation  │  ← Scroll interne
   └─────────────┘
         ↓
   Paramètres → Famille
```

---

## 🔧 Configuration avancée

### Modifier les rôles par défaut

Dans `FamilyTab.tsx` :

```typescript
const DEFAULT_ROLES = [
  'Cuisine',
  'Vaisselle',
  'Poubelles',
  'Salle de bain',
  'Rangement',
  // Ajoute tes rôles personnalisés ici
];
```

### Changer les emojis nourriture

Dans `src/shared/utils/emoji.ts` :

```typescript
const FOOD_EMOJIS = [
  '🍝', '🍕', '🥗', '🍛', // ... ajoute/modifie ici
];
```

### Ajuster les hauteurs Nest Hub

Dans `KitchenPage.css` :

```css
.kitchen-grid {
  grid-template-rows: minmax(220px, 0.6fr) minmax(0, 1fr);
  /* Ajuste les hauteurs selon ton Nest Hub */
}
```

---

## ✅ Checklist de validation

Avant de déployer en production :

### Backend
- [ ] Migration `weekly_menu` exécutée
- [ ] RLS vérifié (user A ne voit pas données de user B)
- [ ] Indexes créés (automatique via migration)
- [ ] Politiques testées (SELECT, INSERT, UPDATE, DELETE)

### Frontend
- [ ] Imports mis à jour dans `ConfigPage` et `App`
- [ ] Route `/kitchen` accessible
- [ ] CSS importé dans les composants
- [ ] Pas d'erreurs console en dev

### UX Tactile
- [ ] Test sur Nest Hub : scroll fluide dans chaque carte
- [ ] Zones tactiles ≥ 48px vérifiées
- [ ] Pas de scroll global involontaire
- [ ] Modaux cliquables sans bug

### Fonctionnel
- [ ] Menu : ajout/modification/suppression repas ✓
- [ ] Épicerie : sync Google Tasks bidirectionnelle ✓
- [ ] Rotation : affichage assignations ✓
- [ ] FamilyTab : ajout/modif/suppression membres ✓
- [ ] Rotation config : assignations sauvegardées ✓

---

## 🐛 Dépannage

### Problème : "Table weekly_menu does not exist"

**Solution** : Exécute la migration SQL dans Supabase Dashboard.

### Problème : Rotation ne s'affiche pas

**Causes possibles :**
1. Table `rotation_assignments` manquante → Vérifie migration `20251218_family_and_rotation.sql`
2. Aucune assignation configurée → Va dans Paramètres → Famille → Configure rotation
3. RLS bloque l'accès → Vérifie `auth.uid()` dans politiques

### Problème : Menu ne se sauvegarde pas

**Vérifications :**
1. User authentifié ? → `useAuth()` doit retourner un user valide
2. Erreurs console ? → Vérifie logs Supabase
3. RLS actif ? → Politiques `weekly_menu` doivent autoriser INSERT/UPDATE

### Problème : Scroll tactile ne fonctionne pas

**Solutions :**
1. Ajoute `-webkit-overflow-scrolling: touch` dans `.panel-scroll`
2. Vérifie `overflow-y: auto` sur les containers
3. Teste sur appareil réel (pas émulateur Chrome)

---

## 📊 Architecture technique

### Flux de données

```
┌─────────────┐
│   USER      │
└──────┬──────┘
       │
       ↓
┌─────────────────┐
│  React Context  │ ← useAuth, useClientConfig
└────────┬────────┘
         │
         ↓
┌─────────────────────┐
│     Services        │
│  ├─ menu.service    │ → Supabase weekly_menu
│  ├─ rotation.service│ → Supabase rotation_assignments
│  └─ google.service  │ → Google Tasks API
└─────────┬───────────┘
          │
          ↓
┌─────────────────────┐
│    Supabase DB      │
│  ├─ weekly_menu     │
│  ├─ rotation_assign │
│  ├─ family_members  │
│  └─ google_connect  │
└─────────────────────┘
```

### Sécurité RLS

Toutes les tables utilisent Row Level Security :

```sql
-- Exemple : weekly_menu
CREATE POLICY "Users manage own menu" ON weekly_menu
  FOR ALL USING (auth.uid() = user_id);
```

Chaque query Supabase filtre automatiquement par `user_id`.

---

## 🎨 Design System

**Palette :**
- Fond : `#030712` (noir profond)
- Accents : `#22d3ee` (cyan), `#a855f7` (violet)
- Texte : `#e2e8f0` (blanc cassé)
- Secondaire : `#94a3b8` (gris)

**Typographie :**
- Famille : Inter ou Poppins
- Body : 16-18px
- Titres : 20-32px

**Tactile :**
- Zones min : 48×48px
- Espacement : 8px minimum
- Coins arrondis : 12-18px
- Transitions : 200ms cubic-bezier

---

## 📝 Notes de développement

### localStorage → Supabase

**Avant** : Menu stocké dans `localStorage` (volatil)
**Après** : Menu persisté dans Supabase (permanent, multi-device)

### Évolution additive

✅ Nouveau code **AJOUTE** sans **CASSER** l'ancien :
- `family_members` copie `children` au déploiement
- Service avec fallback intelligent `children.service.ts`
- Politiques RLS préservées

### Performance

- **Lazy loading** : Composants chargés à la demande
- **Optimistic UI** : Mises à jour immédiates + sync background
- **Cache** : Pas de refetch inutile (useEffect avec deps)

---

## 🤝 Support

Questions ? Problèmes ?

1. Vérifie les logs console (erreurs Supabase)
2. Teste les politiques RLS via Supabase Dashboard
3. Valide les migrations avec `supabase db diff`
4. Demande de l'aide sur le projet GitHub

---

## 📄 Licence

Code propriétaire Hub Familial 2.0 © 2025

---

**Version** : 2.0.0
**Date** : 2025-12-29
**Auteur** : Claude (Anthropic) pour Ahmed
