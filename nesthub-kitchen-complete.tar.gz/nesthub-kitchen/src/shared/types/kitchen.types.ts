/**
 * Types partagés pour le module Kitchen
 */

// =====================================================
// MENU HEBDOMADAIRE
// =====================================================

/**
 * Structure du menu hebdomadaire
 * Clé = ISO date string du jour (ex: "2025-12-29T00:00:00.000Z")
 * Valeur = tableau de noms de repas
 */
export type WeekMenu = Record<string, string[]>;

/**
 * Row de la table weekly_menu
 */
export interface WeekMenuRow {
  id: string;
  user_id: string;
  week_start: string; // ISO timestamp
  day_iso_date: string; // ISO date
  meals: string[];
  created_at: string;
  updated_at: string;
}

// =====================================================
// ROTATION HEBDOMADAIRE
// =====================================================

/**
 * Assignation d'une tâche rotative à un membre
 */
export interface RotationAssignment {
  role: string; // Ex: "Cuisine", "Vaisselle", "Poubelles"
  assigneeMemberId: string;
  assigneeName: string;
  assigneeAvatarUrl?: string;
  sortOrder?: number;
}

/**
 * Rotation complète pour une semaine
 */
export interface RotationWeek {
  weekStart: string; // ISO timestamp du lundi
  assignments: RotationAssignment[];
  adjusted?: boolean; // Rotation ajustée manuellement
  note?: string | null; // Note explicative si ajustée
  rule?: string | null; // Règle de rotation (ex: "Rotation hebdomadaire")
}

/**
 * Row de la table rotation_assignments
 */
export interface RotationAssignmentRow {
  id: string;
  user_id: string;
  week_start: string;
  role: string;
  assignee_member_id: string;
  assignee_name: string;
  assignee_avatar_url: string | null;
  adjusted: boolean | null;
  note: string | null;
  rule: string | null;
  sort_order: number | null;
  created_at: string;
  updated_at: string;
}

/**
 * Configuration d'une règle de rotation
 */
export interface RotationRule {
  id: string;
  userId: string;
  roles: string[]; // Liste des rôles à assigner
  rotationType: 'weekly' | 'biweekly' | 'manual';
  startDate: string; // Date de début de la rotation
  memberOrder: string[]; // IDs des membres dans l'ordre de rotation
}

// =====================================================
// ÉPICERIE (GOOGLE TASKS)
// =====================================================

/**
 * Statut d'une tâche Google
 */
export type GoogleTaskStatus = 'needsAction' | 'completed';

/**
 * Item de la liste d'épicerie
 */
export interface GroceryTask {
  id: string;
  title: string;
  status: GoogleTaskStatus;
  completed?: string; // ISO timestamp si completed
}

// =====================================================
// UI STATE
// =====================================================

/**
 * État de chargement générique
 */
export interface LoadingState {
  loading: boolean;
  error: string | null;
  refreshing: boolean;
}

/**
 * Jour de la semaine
 */
export interface WeekDay {
  label: string; // Ex: "Lun"
  fullLabel: string; // Ex: "Lundi"
  offset: number; // 0-6 (Lun=0, Dim=6)
}

/**
 * Constantes jours de la semaine
 */
export const WEEK_DAYS: WeekDay[] = [
  { label: 'Lun', fullLabel: 'Lundi', offset: 0 },
  { label: 'Mar', fullLabel: 'Mardi', offset: 1 },
  { label: 'Mer', fullLabel: 'Mercredi', offset: 2 },
  { label: 'Jeu', fullLabel: 'Jeudi', offset: 3 },
  { label: 'Ven', fullLabel: 'Vendredi', offset: 4 },
  { label: 'Sam', fullLabel: 'Samedi', offset: 5 },
  { label: 'Dim', fullLabel: 'Dimanche', offset: 6 },
];
