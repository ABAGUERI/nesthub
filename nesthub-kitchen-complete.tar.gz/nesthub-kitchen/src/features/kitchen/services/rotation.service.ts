import { supabase } from '@/shared/utils/supabase';
import {
  RotationWeek,
  RotationAssignment,
  RotationAssignmentRow,
} from '@/shared/types/kitchen.types';

/**
 * Service pour gérer les rotations hebdomadaires de tâches
 */

/**
 * Formater une date pour obtenir le lundi de la semaine
 * @param date Date de référence
 * @returns ISO timestamp du lundi 00:00:00
 */
const formatWeekStart = (date: Date): string => {
  const day = date.getDay();
  const diff = day === 0 ? -6 : 1 - day; // Lundi = 0, Dimanche = -6
  const monday = new Date(date);
  monday.setDate(date.getDate() + diff);
  monday.setHours(0, 0, 0, 0);
  return monday.toISOString();
};

/**
 * Récupérer la rotation de la semaine courante
 * @param userId ID de l'utilisateur
 * @returns Rotation de la semaine ou null si non configurée
 */
export const getCurrentRotation = async (userId: string): Promise<RotationWeek | null> => {
  try {
    const weekStart = formatWeekStart(new Date());

    const { data, error } = await supabase
      .from('rotation_assignments')
      .select('*')
      .eq('user_id', userId)
      .eq('week_start', weekStart)
      .order('sort_order', { ascending: true })
      .order('role', { ascending: true });

    if (error) {
      // Vérifier si la table existe
      if (error.message?.includes("does not exist") || 
          error.message?.includes("Could not find")) {
        console.info('Rotation table not yet available');
        return null;
      }

      console.warn('Error fetching rotation:', error.message);
      return null;
    }

    if (!data || data.length === 0) {
      return null;
    }

    const rows = data as RotationAssignmentRow[];

    // Construire la rotation
    const rotationWeek: RotationWeek = {
      weekStart,
      assignments: rows.map((row) => ({
        role: row.role,
        assigneeMemberId: row.assignee_member_id,
        assigneeName: row.assignee_name,
        assigneeAvatarUrl: row.assignee_avatar_url ?? undefined,
        sortOrder: row.sort_order ?? 0,
      })),
    };

    // Récupérer les métadonnées de la première row
    const [firstRow] = rows;
    if (firstRow) {
      rotationWeek.adjusted = Boolean(firstRow.adjusted);
      rotationWeek.note = firstRow.note ?? null;
      rotationWeek.rule = firstRow.rule ?? null;
    }

    return rotationWeek;
  } catch (error) {
    console.error('Unexpected error in getCurrentRotation:', error);
    return null;
  }
};

/**
 * Récupérer la rotation d'une semaine spécifique
 * @param userId ID de l'utilisateur
 * @param weekStart ISO timestamp du lundi
 * @returns Rotation de la semaine ou null
 */
export const getRotationForWeek = async (
  userId: string,
  weekStart: string
): Promise<RotationWeek | null> => {
  try {
    const { data, error } = await supabase
      .from('rotation_assignments')
      .select('*')
      .eq('user_id', userId)
      .eq('week_start', weekStart)
      .order('sort_order', { ascending: true })
      .order('role', { ascending: true });

    if (error || !data || data.length === 0) {
      return null;
    }

    const rows = data as RotationAssignmentRow[];

    return {
      weekStart,
      assignments: rows.map((row) => ({
        role: row.role,
        assigneeMemberId: row.assignee_member_id,
        assigneeName: row.assignee_name,
        assigneeAvatarUrl: row.assignee_avatar_url ?? undefined,
        sortOrder: row.sort_order ?? 0,
      })),
      adjusted: Boolean(rows[0]?.adjusted),
      note: rows[0]?.note ?? null,
      rule: rows[0]?.rule ?? null,
    };
  } catch (error) {
    console.error('Error in getRotationForWeek:', error);
    return null;
  }
};

/**
 * Sauvegarder/Mettre à jour la rotation d'une semaine
 * @param userId ID de l'utilisateur
 * @param weekStart ISO timestamp du lundi
 * @param assignments Liste des assignations
 * @param options Options supplémentaires
 */
export const saveRotation = async (
  userId: string,
  weekStart: string,
  assignments: RotationAssignment[],
  options?: {
    adjusted?: boolean;
    note?: string;
    rule?: string;
  }
): Promise<void> => {
  try {
    // Supprimer les anciennes assignations de cette semaine
    await supabase
      .from('rotation_assignments')
      .delete()
      .eq('user_id', userId)
      .eq('week_start', weekStart);

    if (assignments.length === 0) {
      return; // Pas d'assignations à créer
    }

    // Créer les nouvelles assignations
    const rows = assignments.map((assignment, index) => ({
      user_id: userId,
      week_start: weekStart,
      role: assignment.role,
      assignee_member_id: assignment.assigneeMemberId,
      assignee_name: assignment.assigneeName,
      assignee_avatar_url: assignment.assigneeAvatarUrl ?? null,
      sort_order: assignment.sortOrder ?? index,
      adjusted: options?.adjusted ?? false,
      note: options?.note ?? null,
      rule: options?.rule ?? null,
    }));

    const { error } = await supabase.from('rotation_assignments').insert(rows);

    if (error) {
      console.error('Error saving rotation:', error);
      throw error;
    }
  } catch (err) {
    console.error('Error in saveRotation:', err);
    throw err;
  }
};

/**
 * Générer automatiquement la rotation de la prochaine semaine
 * Fait une rotation circulaire des membres
 * @param userId ID de l'utilisateur
 */
export const generateNextWeekRotation = async (userId: string): Promise<void> => {
  try {
    const currentWeekStart = formatWeekStart(new Date());
    const nextWeekDate = new Date(currentWeekStart);
    nextWeekDate.setDate(nextWeekDate.getDate() + 7);
    const nextWeekStart = nextWeekDate.toISOString();

    // Récupérer la rotation courante
    const currentRotation = await getRotationForWeek(userId, currentWeekStart);

    if (!currentRotation || currentRotation.assignments.length === 0) {
      throw new Error('No current rotation to base next week on');
    }

    // Faire une rotation circulaire des membres
    const roles = [...new Set(currentRotation.assignments.map((a) => a.role))];
    const members = [...new Set(currentRotation.assignments.map((a) => ({
      id: a.assigneeMemberId,
      name: a.assigneeName,
      avatar: a.assigneeAvatarUrl,
    })))];

    // Décaler les assignations d'un cran
    const newAssignments: RotationAssignment[] = roles.map((role, index) => {
      const currentMemberIndex = currentRotation.assignments.findIndex((a) => a.role === role);
      const nextMemberIndex = (currentMemberIndex + 1) % members.length;
      const member = members[nextMemberIndex];

      return {
        role,
        assigneeMemberId: member.id,
        assigneeName: member.name,
        assigneeAvatarUrl: member.avatar,
        sortOrder: index,
      };
    });

    // Sauvegarder la nouvelle rotation
    await saveRotation(userId, nextWeekStart, newAssignments, {
      adjusted: false,
      rule: currentRotation.rule ?? 'Rotation automatique hebdomadaire',
    });
  } catch (err) {
    console.error('Error in generateNextWeekRotation:', err);
    throw err;
  }
};

/**
 * Supprimer la rotation d'une semaine
 * @param userId ID de l'utilisateur
 * @param weekStart ISO timestamp du lundi
 */
export const deleteRotation = async (userId: string, weekStart: string): Promise<void> => {
  try {
    const { error } = await supabase
      .from('rotation_assignments')
      .delete()
      .eq('user_id', userId)
      .eq('week_start', weekStart);

    if (error) {
      console.error('Error deleting rotation:', error);
      throw error;
    }
  } catch (err) {
    console.error('Error in deleteRotation:', err);
    throw err;
  }
};

/**
 * Vérifier si une rotation existe pour la semaine courante
 * @param userId ID de l'utilisateur
 * @returns true si une rotation existe
 */
export const hasCurrentRotation = async (userId: string): Promise<boolean> => {
  const rotation = await getCurrentRotation(userId);
  return rotation !== null && rotation.assignments.length > 0;
};
