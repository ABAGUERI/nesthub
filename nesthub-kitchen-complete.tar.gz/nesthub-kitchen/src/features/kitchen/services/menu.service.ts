import { supabase } from '@/shared/utils/supabase';
import { WeekMenu, WeekMenuRow } from '@/shared/types/kitchen.types';

/**
 * Service pour gérer le menu hebdomadaire
 * Utilise Supabase pour la persistance
 */

/**
 * Récupérer le menu d'une semaine spécifique
 * @param userId ID de l'utilisateur
 * @param weekStart ISO timestamp du lundi de la semaine
 * @returns Menu structuré par jour
 */
export const getWeekMenu = async (userId: string, weekStart: string): Promise<WeekMenu> => {
  try {
    const { data, error } = await supabase
      .from('weekly_menu')
      .select('*')
      .eq('user_id', userId)
      .eq('week_start', weekStart);

    if (error) {
      console.error('Error fetching weekly menu:', error);
      return {};
    }

    if (!data || data.length === 0) {
      return {};
    }

    // Transformer les rows en WeekMenu
    const menu: WeekMenu = {};
    (data as WeekMenuRow[]).forEach((row) => {
      menu[row.day_iso_date] = row.meals || [];
    });

    return menu;
  } catch (err) {
    console.error('Unexpected error in getWeekMenu:', err);
    return {};
  }
};

/**
 * Sauvegarder le menu d'une semaine
 * @param userId ID de l'utilisateur
 * @param weekStart ISO timestamp du lundi
 * @param weekMenu Menu complet de la semaine
 */
export const saveWeekMenu = async (
  userId: string,
  weekStart: string,
  weekMenu: WeekMenu
): Promise<void> => {
  try {
    // Supprimer d'abord tous les jours vides (optimisation)
    const nonEmptyDays = Object.entries(weekMenu).filter(
      ([, meals]) => meals && meals.length > 0
    );

    if (nonEmptyDays.length === 0) {
      // Si tout est vide, supprimer tous les enregistrements de cette semaine
      await supabase
        .from('weekly_menu')
        .delete()
        .eq('user_id', userId)
        .eq('week_start', weekStart);
      return;
    }

    // Upsert chaque jour individuellement
    const promises = nonEmptyDays.map(([dayIso, meals]) => {
      return supabase.from('weekly_menu').upsert(
        {
          user_id: userId,
          week_start: weekStart,
          day_iso_date: dayIso,
          meals: meals,
        },
        {
          onConflict: 'user_id,week_start,day_iso_date',
        }
      );
    });

    const results = await Promise.all(promises);

    // Vérifier les erreurs
    const errors = results.filter((r) => r.error);
    if (errors.length > 0) {
      console.error('Errors saving weekly menu:', errors);
      throw new Error('Failed to save some days');
    }
  } catch (err) {
    console.error('Error in saveWeekMenu:', err);
    throw err;
  }
};

/**
 * Supprimer un jour spécifique du menu
 * @param userId ID de l'utilisateur
 * @param weekStart ISO timestamp du lundi
 * @param dayIso ISO date du jour à supprimer
 */
export const deleteMenuDay = async (
  userId: string,
  weekStart: string,
  dayIso: string
): Promise<void> => {
  try {
    const { error } = await supabase
      .from('weekly_menu')
      .delete()
      .eq('user_id', userId)
      .eq('week_start', weekStart)
      .eq('day_iso_date', dayIso);

    if (error) {
      console.error('Error deleting menu day:', error);
      throw error;
    }
  } catch (err) {
    console.error('Error in deleteMenuDay:', err);
    throw err;
  }
};

/**
 * Dupliquer le menu d'une semaine vers une autre
 * @param userId ID de l'utilisateur
 * @param sourceWeekStart Semaine source
 * @param targetWeekStart Semaine cible
 */
export const duplicateWeekMenu = async (
  userId: string,
  sourceWeekStart: string,
  targetWeekStart: string
): Promise<void> => {
  try {
    // Récupérer le menu source
    const sourceMenu = await getWeekMenu(userId, sourceWeekStart);

    if (Object.keys(sourceMenu).length === 0) {
      throw new Error('Source week menu is empty');
    }

    // Ajuster les dates pour la semaine cible
    const targetMenu: WeekMenu = {};
    const sourceMon = new Date(sourceWeekStart);
    const targetMon = new Date(targetWeekStart);
    const dayDiff = Math.round(
      (targetMon.getTime() - sourceMon.getTime()) / (1000 * 60 * 60 * 24)
    );

    Object.entries(sourceMenu).forEach(([dayIso, meals]) => {
      const sourceDate = new Date(dayIso);
      const targetDate = new Date(sourceDate);
      targetDate.setDate(sourceDate.getDate() + dayDiff);
      targetMenu[targetDate.toISOString()] = meals;
    });

    // Sauvegarder le menu dupliqué
    await saveWeekMenu(userId, targetWeekStart, targetMenu);
  } catch (err) {
    console.error('Error in duplicateWeekMenu:', err);
    throw err;
  }
};

/**
 * Nettoyer les vieux menus (plus de 8 semaines)
 * @param userId ID de l'utilisateur
 */
export const cleanupOldMenus = async (userId: string): Promise<void> => {
  try {
    const eightWeeksAgo = new Date();
    eightWeeksAgo.setDate(eightWeeksAgo.getDate() - 56); // 8 semaines

    const { error } = await supabase
      .from('weekly_menu')
      .delete()
      .eq('user_id', userId)
      .lt('week_start', eightWeeksAgo.toISOString());

    if (error) {
      console.error('Error cleaning up old menus:', error);
    }
  } catch (err) {
    console.error('Error in cleanupOldMenus:', err);
  }
};
