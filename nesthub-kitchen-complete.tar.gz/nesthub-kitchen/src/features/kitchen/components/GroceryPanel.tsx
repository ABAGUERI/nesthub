import React, { useEffect, useMemo, useState } from 'react';
import { useAuth } from '@/shared/hooks/useAuth';
import { useClientConfig } from '@/shared/hooks/useClientConfig';
import {
  createTaskWithAuth,
  getGoogleConnection,
  getTasksWithAuth,
  GoogleTaskItem,
  GoogleTaskStatus,
  updateTaskStatusWithAuth,
} from '@/features/google/google.service';
import { GroceryTask } from '@/shared/types/kitchen.types';

/**
 * Composant GroceryPanel
 * Affiche et gère la liste d'épicerie via Google Tasks
 * Source unique: Google Tasks (pas de duplication)
 */
export const GroceryPanel: React.FC = () => {
  const { user } = useAuth();
  const { config } = useClientConfig();
  const [tasks, setTasks] = useState<GroceryTask[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [newItem, setNewItem] = useState('');
  const [listId, setListId] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  // Nom de la liste résolu depuis config
  const resolvedListName = useMemo(() => {
    return config?.googleGroceryListName || 'Épicerie';
  }, [config?.googleGroceryListName]);

  // Charger les tâches au montage
  useEffect(() => {
    loadGroceryTasks();
  }, [user, config?.googleGroceryListId]);

  /**
   * Charger les tâches depuis Google Tasks
   */
  const loadGroceryTasks = async () => {
    if (!user) {
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      // Récupérer la connexion Google
      const connection = await getGoogleConnection(user.id);
      const targetListId = connection?.groceryListId || config?.googleGroceryListId;

      if (!targetListId) {
        setError('Liste Épicerie non configurée dans Google Tasks');
        setTasks([]);
        setListId(null);
        setLoading(false);
        return;
      }

      setListId(targetListId);

      // Récupérer les tâches
      const remoteTasks = await getTasksWithAuth(user.id, targetListId);
      const normalized: GroceryTask[] = (remoteTasks || []).map((task: GoogleTaskItem) => ({
        id: task.id,
        title: task.title,
        status: task.status as GoogleTaskStatus,
        completed: task.completed,
      }));

      setTasks(normalized);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Erreur inconnue';
      const isUnauthorized = message === 'unauthorized';
      setError(
        isUnauthorized
          ? 'Session Google expirée : reconnectez-vous dans Paramètres > Google.'
          : 'Échec de synchronisation'
      );
      console.error('Grocery tasks load error:', err);
    } finally {
      setLoading(false);
    }
  };

  /**
   * Toggle le statut d'une tâche (checked/unchecked)
   */
  const handleToggle = async (taskId: string) => {
    if (!user || !listId) return;

    const current = tasks.find((task) => task.id === taskId);
    if (!current) return;

    const nextStatus: GoogleTaskStatus =
      current.status === 'completed' ? 'needsAction' : 'completed';

    // Mise à jour optimiste
    setTasks((prev) =>
      prev.map((task) =>
        task.id === taskId
          ? {
              ...task,
              status: nextStatus,
              completed: nextStatus === 'completed' ? new Date().toISOString() : undefined,
            }
          : task
      )
    );

    // Mise à jour serveur
    try {
      const updated = await updateTaskStatusWithAuth(user.id, listId, taskId, nextStatus);
      setTasks((prev) => prev.map((task) => (task.id === taskId ? updated : task)));
    } catch (err) {
      console.error('Toggle grocery task failed', err);
      setError('Échec de synchronisation');
      // Rollback optimiste
      setTasks((prev) => prev.map((task) => (task.id === taskId ? current : task)));
    }
  };

  /**
   * Ajouter un nouvel item
   */
  const handleAdd = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!user || !listId) return;

    const trimmed = newItem.trim();
    if (!trimmed) return;

    const tempId = `temp-${Date.now()}`;
    const optimisticTask: GroceryTask = {
      id: tempId,
      title: trimmed,
      status: 'needsAction',
    };

    // Ajout optimiste
    setTasks((prev) => [optimisticTask, ...prev]);
    setNewItem('');

    // Création serveur
    try {
      const created = await createTaskWithAuth(user.id, listId, trimmed);
      setTasks((prev) => prev.map((task) => (task.id === tempId ? created : task)));
    } catch (err) {
      console.error('Add grocery task failed', err);
      setError("Impossible d'ajouter cet item");
      // Rollback optimiste
      setTasks((prev) => prev.filter((task) => task.id !== tempId));
    }
  };

  /**
   * Réessayer le chargement
   */
  const handleRetry = () => {
    setRefreshing(true);
    loadGroceryTasks().finally(() => setRefreshing(false));
  };

  /**
   * Rendu du contenu principal
   */
  const renderContent = () => {
    if (loading) {
      return (
        <div className="panel-loading">
          <div className="skeleton-line" />
          <div className="skeleton-line short" />
          <div className="skeleton-line" />
        </div>
      );
    }

    if (error) {
      return (
        <div className="panel-empty">
          <p>{error}</p>
          <button className="ghost-btn" onClick={handleRetry} disabled={refreshing}>
            {refreshing ? 'Rechargement...' : 'Réessayer'}
          </button>
        </div>
      );
    }

    if (!tasks.length) {
      return <div className="panel-empty">Liste vide</div>;
    }

    return (
      <div className="grocery-list">
        {tasks.map((task) => (
          <button
            key={task.id}
            className={`grocery-row ${task.status === 'completed' ? 'done' : ''}`}
            onClick={() => handleToggle(task.id)}
            aria-label={`${task.status === 'completed' ? 'Décocher' : 'Cocher'} ${task.title}`}
          >
            <span className="checkbox">{task.status === 'completed' ? '✓' : ''}</span>
            <span className="grocery-title">{task.title}</span>
          </button>
        ))}
      </div>
    );
  };

  return (
    <div className="kitchen-card">
      <div className="kitchen-card-header">
        <div>
          <p className="card-kicker">Google Tasks</p>
          <h3>Épicerie — {resolvedListName}</h3>
        </div>
        <button
          className="ghost-btn"
          onClick={handleRetry}
          disabled={refreshing}
          aria-label="Rafraîchir la liste"
        >
          {refreshing ? '⏳' : '🔄'}
        </button>
      </div>

      <form className="grocery-form" onSubmit={handleAdd}>
        <input
          type="text"
          value={newItem}
          onChange={(e) => setNewItem(e.target.value)}
          placeholder="Ajouter un item"
          className="grocery-input"
          disabled={!listId}
          aria-label="Nouvel item d'épicerie"
        />
        <button
          type="submit"
          className="primary-btn"
          disabled={!listId || !newItem.trim()}
        >
          Ajouter
        </button>
      </form>

      <div className="panel-scroll">
        {listId || loading || error ? (
          renderContent()
        ) : (
          <div className="panel-empty">
            <p>Google Tasks non configuré</p>
            <a href="/config" className="ghost-btn">
              Configurer
            </a>
          </div>
        )}
      </div>
    </div>
  );
};
