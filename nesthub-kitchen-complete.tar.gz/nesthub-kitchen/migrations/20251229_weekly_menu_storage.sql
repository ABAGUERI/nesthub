-- =====================================================
-- MIGRATION: Weekly Menu Storage + Rotation Enhancements
-- Date: 2025-12-29
-- Description: Ajoute la persistance du menu hebdomadaire et améliore la table de rotations
-- =====================================================

-- =====================================================
-- TABLE: weekly_menu
-- Stockage du menu de la semaine par utilisateur
-- =====================================================
CREATE TABLE IF NOT EXISTS weekly_menu (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  week_start TIMESTAMP WITH TIME ZONE NOT NULL,
  day_iso_date TEXT NOT NULL, -- Format ISO complet de la journée (ex: 2025-12-29T00:00:00.000Z)
  meals TEXT[] DEFAULT ARRAY[]::TEXT[], -- Tableau de noms de repas
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, week_start, day_iso_date)
);

-- Index pour recherche rapide par utilisateur et semaine
CREATE INDEX IF NOT EXISTS idx_weekly_menu_user_week 
  ON weekly_menu(user_id, week_start);

-- Index pour recherche par jour spécifique
CREATE INDEX IF NOT EXISTS idx_weekly_menu_day 
  ON weekly_menu(user_id, day_iso_date);

-- RLS: Les utilisateurs ne voient que leurs propres menus
ALTER TABLE weekly_menu ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users manage own weekly menu" ON weekly_menu;
CREATE POLICY "Users manage own weekly menu" 
  ON weekly_menu 
  FOR ALL 
  USING (auth.uid() = user_id);

-- Trigger pour mettre à jour updated_at
DROP TRIGGER IF EXISTS update_weekly_menu_updated_at ON weekly_menu;
CREATE TRIGGER update_weekly_menu_updated_at
  BEFORE UPDATE ON weekly_menu
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- AMÉLIORATIONS: rotation_assignments
-- Ajoute des colonnes utiles si elles n'existent pas
-- =====================================================

-- Ajouter une colonne pour l'ordre d'affichage
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'rotation_assignments' 
    AND column_name = 'sort_order'
  ) THEN
    ALTER TABLE rotation_assignments 
      ADD COLUMN sort_order INTEGER DEFAULT 0;
  END IF;
END $$;

-- Index pour tri des rotations
CREATE INDEX IF NOT EXISTS idx_rotation_assignments_sort 
  ON rotation_assignments(user_id, week_start, sort_order);

-- =====================================================
-- FUNCTION: Nettoyer les vieux menus (optionnel)
-- Garde seulement les 8 dernières semaines de menus
-- =====================================================
CREATE OR REPLACE FUNCTION cleanup_old_weekly_menus()
RETURNS void AS $$
BEGIN
  DELETE FROM weekly_menu
  WHERE week_start < NOW() - INTERVAL '8 weeks';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Optionnel: Créer un job cron pour nettoyer automatiquement
-- (Nécessite l'extension pg_cron, décommente si disponible)
-- SELECT cron.schedule('cleanup-old-menus', '0 2 * * 0', 'SELECT cleanup_old_weekly_menus()');

-- =====================================================
-- SEED DATA: Exemple de rotation par défaut
-- Pour faciliter l'onboarding
-- =====================================================
COMMENT ON TABLE weekly_menu IS 'Stocke les menus hebdomadaires par jour pour chaque utilisateur';
COMMENT ON TABLE rotation_assignments IS 'Gère les assignations de tâches rotatives hebdomadaires';

-- =====================================================
-- FIN DE LA MIGRATION
-- =====================================================
