import React from 'react';
import { Link } from 'react-router-dom';
import { MenuPanel } from './components/MenuPanel';
import { GroceryPanel } from './components/GroceryPanel';
import { RotationPanel } from './components/RotationPanel';
import './KitchenPage.css';

/**
 * KitchenPage - Version moderne épurée
 * Layout: Menu vertical à gauche | Stack Épicerie+Rotation à droite
 */
export const KitchenPage: React.FC = () => {
  return (
    <div className="kitchen-page">
      {/* Header simplifié */}
      <header className="kitchen-hero">
        <h1>Cuisine</h1>
        <div className="kitchen-actions">
          <Link to="/dashboard" className="ghost-btn" aria-label="Retour au tableau de bord">
            ← Dashboard
          </Link>
          <Link to="/config" className="ghost-btn" aria-label="Ouvrir les paramètres">
            ⚙️ Paramètres
          </Link>
        </div>
      </header>

      {/* Grid moderne: Menu 50% | Sidebar 50% */}
      <div className="kitchen-grid">
        {/* Menu de la semaine (format vertical, un jour à la fois) */}
        <section className="menu-area" aria-label="Menu de la semaine">
          <MenuPanel />
        </section>

        {/* Sidebar: Stack Épicerie + Rotation */}
        <div className="kitchen-sidebar">
          {/* Liste d'épicerie */}
          <section className="grocery-area" aria-label="Liste d'épicerie">
            <GroceryPanel />
          </section>

          {/* Rotation des tâches */}
          <section className="rotation-area" aria-label="Rotation hebdomadaire">
            <RotationPanel />
          </section>
        </div>
      </div>
    </div>
  );
};
